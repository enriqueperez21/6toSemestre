import React from "react";

function Contact(){
    return <h2>Contacto</h2>;
}

export default Contact;