function Saludo ({nombre}){
    return(
        <>
        <p>{nombre} Bienvenido a mi aplicación Web</p>
        </>
    )
}

export default Saludo