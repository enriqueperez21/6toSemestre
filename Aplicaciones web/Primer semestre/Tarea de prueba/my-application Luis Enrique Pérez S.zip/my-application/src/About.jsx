import React from "react";

function About(){
    return <h2>Acerca de nosotros</h2>;
}

export default About;