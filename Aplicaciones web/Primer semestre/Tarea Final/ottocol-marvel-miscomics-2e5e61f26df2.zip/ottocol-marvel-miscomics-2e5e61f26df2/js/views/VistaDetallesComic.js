Marvel.Views = Marvel.Views || {};

(function () {
    'use strict';

    Marvel.Views.VistaDetallesComic = Mn.ItemView.extend({
        template: '#VistaDetallesComicTmpl'
    });

})();