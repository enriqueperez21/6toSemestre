Marvel.Views = Marvel.Views || {};

(function () {
    'use strict';

    Marvel.Views.VistaBuscarComics = Mn.ItemView.extend({
        template: '#VistaBuscarComicsTmpl'
    });

})();
