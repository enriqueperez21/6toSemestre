Marvel.Views = Marvel.Views || {};

(function () {
    'use strict';

    Marvel.Views.VistaComic = Mn.ItemView.extend({
        template: '#VistaComicTmpl'
    });

})();
