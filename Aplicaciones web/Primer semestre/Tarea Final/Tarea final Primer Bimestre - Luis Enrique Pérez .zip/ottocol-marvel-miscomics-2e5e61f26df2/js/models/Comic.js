Marvel.Models = Marvel.Models || {};

(function () {
    'use strict';

    Marvel.Models.Comic = Backbone.Model.extend({
    });

})();
